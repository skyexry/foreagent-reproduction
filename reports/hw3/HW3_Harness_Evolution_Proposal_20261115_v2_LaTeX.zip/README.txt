Compile main.tex with latexmk -pdf main.tex. Revision v2 expands Baseline Explanation and reorganizes the end-to-end Baseline Reproduction.
