Compile main.tex with latexmk -pdf main.tex. Figures are included; regenerating them requires the archived logs in the original repository. Revision v3 aligns the baseline sections with the rubric.
